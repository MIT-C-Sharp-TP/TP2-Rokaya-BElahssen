using System;
using UnityEngine;
// A coin that the car picks up. Its Box Collider has "Is Trigger" ticked.
public class Coin : MonoBehaviour
{
// raised when any coin is picked up
public static event Action Collected;
[SerializeField] private float rotationSpeed = 90f; // degrees per second
[SerializeField] private GameObject collectEffect; // optional
void Update()
{
// Time.deltaTime: the same speed on a slow and on a fast computer
transform.Rotate(0f, 0f, rotationSpeed * Time.deltaTime);
}
void OnTriggerEnter(Collider other)
{
// only the car collects coins
if (!other.CompareTag("Player"))
{
return;
}
if (collectEffect != null)
{
Instantiate(collectEffect, transform.position, Quaternion.identity);
}
Collected?.Invoke();
Destroy(gameObject); 
}
}