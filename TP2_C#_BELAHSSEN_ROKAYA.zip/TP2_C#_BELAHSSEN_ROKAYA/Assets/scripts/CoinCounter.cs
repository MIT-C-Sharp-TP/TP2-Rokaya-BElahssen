
using UnityEngine;

public class CoinCounter : MonoBehaviour
{
    private int coins = 0;       // Nombre de pièces récupérées
    private int coinsToWin = 0;  // Nombre total de pièces

    void OnEnable()
    {
        // S'abonner à l'événement
        Coin.Collected += AddCoin;
    }

    void OnDisable()
    {
        // Se désabonner de l'événement
        Coin.Collected -= AddCoin;
    }

    void Start()
    {
        // Compter les pièces présentes dans la scène
        coinsToWin = FindObjectsByType<Coin>(
            FindObjectsSortMode.None
        ).Length;

        Debug.Log($"Collect the {coinsToWin} coins!");
    }

    private void AddCoin()
    {
        coins++;

        Debug.Log($"Coins: {coins} / {coinsToWin}");

        if (coins == coinsToWin)
        {
            Debug.Log("All coins collected!");
        }
    }
}
